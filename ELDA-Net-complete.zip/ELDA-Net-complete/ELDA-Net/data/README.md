# Data Directory

Place datasets here:

```
data/
├── tusimple/
│   ├── images/   <- .jpg/.png frames
│   └── labels/   <- binary mask files (same filenames, 255=lane 0=bg)
└── culane/
    ├── images/
    └── labels/
```

TuSimple: https://github.com/TuSimple/tusimple-benchmark
CULane:   https://xingangpan.github.io/projects/CULane.html
